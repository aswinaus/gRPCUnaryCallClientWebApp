﻿using gRPCUnaryCallClientWebApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Grpc.Net.Client;
using GrpcService1;
using System.Threading;
using Grpc.Core;

namespace gRPCUnaryCallClientWebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public async Task<IActionResult> Unary()
        {
            var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Greeter.GreeterClient(channel);
            var reply = await client.SendJokeAsync(new JRequest { No = 2 });

            return View("ShowJoke", (object)ChangetoDictionary(reply));
        }

        private Dictionary<string, string> ChangetoDictionary(JResponse response)
        {
            Dictionary<string, string> jokeDict = new Dictionary<string, string>();
            foreach (Joke joke in response.Joke)
                jokeDict.Add(joke.Author, joke.Description);
            return jokeDict;
        }

        public async Task<IActionResult> ServerStreaming()
        {
            var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Greeter.GreeterClient(channel);

            Dictionary<string, string> jokeDict = new Dictionary<string, string>();

            var cts = new CancellationTokenSource();
            cts.CancelAfter(TimeSpan.FromSeconds(5));

            using (var call = client.SendJokeSS(new JRequest { No = 5 }, cancellationToken: cts.Token))
            {
                try
                {
                    await foreach (var message in call.ResponseStream.ReadAllAsync())
                    {
                        jokeDict.Add(message.Joke[0].Author, message.Joke[0].Description);
                    }
                }
                catch (RpcException ex) when (ex.StatusCode == Grpc.Core.StatusCode.Cancelled)
                {
                    // Log Stream cancelled
                }
            }

            return View("ShowJoke", (object)jokeDict);
        }

        public async Task<IActionResult> ClientStreaming()
        {
            var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Greeter.GreeterClient(channel);

            Dictionary<string, string> jokeDict = new Dictionary<string, string>();
            int[] jokes = { 3, 2, 4 };

            using (var call = client.SendJokesCS())
            {
                foreach (var jT in jokes)
                {
                    await call.RequestStream.WriteAsync(new JRequest { No = jT });
                }
                await call.RequestStream.CompleteAsync();

                JResponse jRes = await call.ResponseAsync;

                foreach (Joke joke in jRes.Joke)
                    jokeDict.Add(joke.Author, joke.Description);
            }

            return View("ShowJoke", (object)jokeDict);
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public async Task<IActionResult> BiDirectionalStreaming()
        {
            var channel = GrpcChannel.ForAddress("https://localhost:5001");
            var client = new Greeter.GreeterClient(channel);

            Dictionary<string, string> jokeDict = new Dictionary<string, string>();

            using (var call = client.SendJokesBD())
            {
                var responseReaderTask = Task.Run(async () =>
                {
                    while (await call.ResponseStream.MoveNext())
                    {
                        var response = call.ResponseStream.Current;
                        foreach (Joke joke in response.Joke)
                            jokeDict.Add(joke.Author, joke.Description);
                    }
                });

                int[] jokeNo = { 3, 2, 5 };
                foreach (var jT in jokeNo)
                {
                    await call.RequestStream.WriteAsync(new JRequest { No = jT });
                }

                await call.RequestStream.CompleteAsync();
                await responseReaderTask;
            }
            return View("ShowJoke", (object)jokeDict);
        }
        //public async Task<IActionResult> FileDownLoad()
        //{
        //    FileInfo v = new FileInfo
        //    {
        //        FileName = "test.pdf"
        //    };
        //    BytesContent contentStruct;
        //    List<BytesContent> contentList = new List<BytesContent>();
        //    using (var call = client.FileDownLoad(info))
        //    {
        //        var reaponseStream = call.ResponseStream;
        //        while (await reaponseStream.MoveNext())
        //        {
        //            contentStruct = reaponseStream.Current;
        //            contentList.Add(contentStruct);
        //        }
        //        FileStream fs = new FileStream(contentList[0].fileName, FileMode.Create, FileAccess.ReadWrite);
        //        contentList.OrderBy(x => x.Block).ToList.ForEach(x => x.content.WriteTo(fs));
        //        fs.close();
        //    }
        //}

    }
}